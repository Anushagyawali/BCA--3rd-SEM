class Subject {
    private int math;
        public void setMath(int marks) {
        this.math = marks;
    }

    public int getMath() {
        return this.math;
    }

}

public class AccessModifier {
    public static void main(String[] args) {
        Subject s = new Subject();
        s.setMath(89);
        System.out.println("Math marks:" + s.getMath());
    }
}

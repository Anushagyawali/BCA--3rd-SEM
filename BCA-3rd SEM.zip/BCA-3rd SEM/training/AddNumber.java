public class AddNumber {

public void displaySum(int a, int b){
System.out.println(a + b);
}
public void displaySub(int c, int d){
System.out.println(c - d);
}
public void displayMul(int e, int f){
System.out.println(e * f); 
}

public void displayDiv(int g, int h){
System.out.println(g / h);
}
public static void main (String [] args){
AddNumber num = new AddNumber();
num.displaySum(1,2); 
num.displaySub(4,2);
num.displayMul(2,4);
num.displayDiv(2,4);
}
}
public class Rectangle{

 public int length;
 public int breadth;

public Rectangle(){
this.length = 0;
this.breadth = 0;
}

// parameterized constructor
public Rectangle(int l , int b){
this.length = l;
this.breadth = b;
}

public void perimeter(){
int result = 2*(length + breadth);
System.out.println("result:"+ result);
}

public static void main(String[] args){
Rectangle myrect = new Rectangle(2,4);
myrect.perimeter();

}
}
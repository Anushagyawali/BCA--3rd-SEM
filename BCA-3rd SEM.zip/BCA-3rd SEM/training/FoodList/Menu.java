import java.util.ArrayList;
import java.util.Scanner;

public class Menu{
    public ArrayList<Food> foodList;

    public Menu() {
        this.foodList = new ArrayList<>();
    }

    public Menu(ArrayList<Food> foodList) {
        this.foodList = foodList;
    }
    

    public ArrayList<Food> getFoodList() {
        return this.foodList;
    }

    public void addFood(Food food) {
        this.foodList.add(food);
    }

    public void  removeFood(String name) {
        for (Food food : foodList) {
            if (food.getName().equals(name)) {
                foodList.remove(food);
                break;
            }
        }
    }

    public double getFoodPrice(String name) {
        for (Food food : foodList) {
            if (food.getName().equals(name)) {
                return food.getPrice();
            }

        }
        return -1;
    }

    public static void main(String []args){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter Food name");
        String name = scan.nextLine();
        int price = scan.nextInt();
        m.addFood(new Food(name,price));

        m.geAllFood();




        

        Menu m = new Menu();
        m.addFood(new Food("Tea", 28));
        System.out.println(m.getFoodPrice("Tea"));
    }
}
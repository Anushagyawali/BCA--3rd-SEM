class Food {
    private String name;
    private int price;

    Food(String name, int price) {
        this.name = name;
        this.price = price;
    }

    Food() {}

    void setName(String name) {
        this.name = name;
    }

    void setPrice(int price) {
        this.price = price;
    }

    public String getName() {
        return this.name;
    }

    public int getPrice() {
        return this.price;
    }

    public String toString(){
        return "\n{Name: "+this.name+ " Price: "+this.getPrice()+"}";
    }
}
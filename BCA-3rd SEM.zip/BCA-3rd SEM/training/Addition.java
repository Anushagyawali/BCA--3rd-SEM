class Arithmetic {
 void addTwoDigit(int a, int b){
        System.out.println("Addition of two digits:"+(a+b));

    }
}
public class Addition extends Arithmetic{
    {
    }
    public static void main(String[] args) {
        Arithmetic obj = new Arithmetic();
        obj. addTwoDigit(2, 5);
    }
}


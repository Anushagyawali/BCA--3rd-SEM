public class Descending{
    public static void main(String[] args){
      int numbers[] = {15, 11, 33, 11, 45, 23, 35, 35, 15,43};
      int size = numbers.length;
      int maxIndex;
      int maxValue;
  
      System.out.println("Numbers before sorting");
      for (int i = 0; i < size; i++){
        System.out.print(numbers[i]+ " " );
      }
  
      for (int i = 0; i < size-1; i++){
        maxIndex = i;
        maxValue = numbers[i];
        for (int j = i+1 ; j<size ; j++){
          if (numbers [j] > maxValue){
            maxIndex = j;
            maxValue = numbers[j];
          }
        }
        int temp = numbers[i];
        numbers[i] = maxValue;
        numbers[maxIndex] = temp;
      }
      System.out.println();
  
      System.out.print("After Sorting");
  
      System.out.println();
  
      for (int i = 0; i<size ; i++){
        System.out.print(numbers[i] + " ");
      }
  
    }
  }
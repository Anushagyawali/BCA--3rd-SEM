class FoodList {

    public static void main(String[] args) {
        
    }


    private String name;
    private int price;

    FoodList() {

    };
    void setName (String name)
    {
        this.name = name;

    }
    void setPrice (int price)
    {
        this.price = 450;
    }

    String getName(){
return this.name;
    }
     
    int getPrice(){
        return this.price;
    }

    
        
    }

public class Example{
    public static void main(String[] args) {
        Food f1 = new Food();
        f1.setName("MoMo");
        f1.setPrice("150");

        Food f2 = new Food();
        f2.setName(""Samosa);
        f2.setPrice("20");
        ArrayList<Food>menu
    }
}
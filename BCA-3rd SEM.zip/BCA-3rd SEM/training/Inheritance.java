class Flower(){
    void blooming(){
        System.out.println("this flower is pretty");
    }
}

class Rose extends Flower{
    void smellsgood(){
        System.out.println("flowers bloom");
    }
}
public class Inheritance extends Flower{
    public static void main(String[] args) {
        Rose obj = new Rose();
        
    }
}
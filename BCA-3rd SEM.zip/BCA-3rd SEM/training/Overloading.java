class Example{
    int add(int a, int b){
        return a+b;
    }
    int add(int a, int b, int c){
        return a+b+c;
    }
}
public class Overloading{
    public static void main(String[] args) {
        Example example = new Example();
        System.out.println(example.add(3, 2));
        System.out.println(example.add(3, 2,5));
    }
}
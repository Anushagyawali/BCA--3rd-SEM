 // wrapper class
    //  int num = 5;
    // string a = string.value(a); convert int to string
    // string b = "6";
    // int b = Integer.paraseInt(b) convert string to int

    // Array list
    // arraylist list = new arrayList();
    // list.add("orange");
    // list.add("Blue");
    // list.add("white");


    import java.util.ArrayList;


    class Example{
        String msg;

        Example(){
            msg = "This is message";
        }

        void display(){
            System.out.println(msg);
        }
    }

    public class ArrayListExample {
    public static void main(String[] args) {
        ArrayList<Object> list = new ArrayList();
        Example ex = new Example();

        list.add("orange");
        list.add(1);

        list.add("Blue");

        list.add(ex);

        boolean isContain = list.contains("orange");
        System.out.println("Does orange exist in list:" + isContain);

        System.out.println(list);

        list.remove(ex);
        System.out.println(list);

        ArrayList<String> stringlList = new ArrayList<String>();
        stringlList.add("brown");

    }
        
    }

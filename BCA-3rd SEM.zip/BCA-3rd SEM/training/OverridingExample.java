class Car {
    void speed() {
        System.out.println("Car makes a sound");
    }
    void smooth(){
        System.out.println("this car runs smooth");
    }
    void price(){
        System.out.println("it is expensive");
    }
}

class BYD extends Car {
    void speed() {
        System.out.println("this car run smoothly");
    }
    void price(){
        System.out.println("BYD is expensive");
    }
}

public class OverridingExample {
    public static void main(String[] args) {
        BYD myCar = new BYD(); // 
        myCar.speed();
        myCar.price();
        
    }
}

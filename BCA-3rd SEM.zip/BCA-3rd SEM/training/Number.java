public class Number {

    public int getLargest(int[] arr){
        int n = arr.length;
        int large = arr[0];
        for(int i=1; i<n; i++)
        {
            if(large<arr[i])
            {
                large= arr[i];

            }
        }
              return large;
    }
    public static void main(String[] args) {
        Number num = new Number();
        int[] array = {2,3,5,6,7,4};
        int largest = num.getLargest(array);
        System.out.println("Largest Number is :"+ largest);
    }
}


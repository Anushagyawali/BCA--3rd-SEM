import java.util.Scanner;
public class LargestInterger{

    public int getLargest(int[]arr)
    {
        int n= arr.length;
        int largest=0;
        for(int i=1; i<n; i++){
            if(largest<arr[i]){
                if(arr[i]%2 != 0){
                    // largest=i;
                    largest=arr[i];
                }

                // largest=arr[i];
            }
        }
        return largest;
    }   
    
    public static void main(String[]args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter a length of array:");
        int n=scanner.nextInt();

        int[] array= new int[n];

        System.out.println("Enter" +n+" numbers:");
        for(int i=0;i<n;i++){
            array[i]=scanner.nextInt();
        }
        LargestInterger num= new LargestInterger();

        int max=num.getLargest(array);
        System.out.println("Largest Number is:" + max);
    }
}

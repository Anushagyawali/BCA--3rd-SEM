class BankAccount {
    private long accountNumber;
    private String holderName;
    private double balance;

    public BankAccount(long accountNumber, String holderName, double balance){
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.balance = balance;
    }

    void deposit(double amount){
        if(amount>0){
            balance += amount;
            System.out.println("Deposited:"+ amount);
        } else{
            System.out.println("invalid balance" );
        }
    }
        
    
        void withdraw(double amount){
        if(amount>0 && amount<this.balance){
        balance -= amount;
        System.out.println("withdrawn:"+ amount);
        }else{
        System.out.println("Insufficient balance");
        }
        }
void displayBalance(){
    System.out.println("Balance:"+ balance);
}
public static void main(String[] args) {
    BankAccount account = new BankAccount(12345, "Anusha", 123456.7);
    account.displayBalance();
    account.deposit(50000);
    account.displayBalance();
    account.withdraw(2345);
    
}

}
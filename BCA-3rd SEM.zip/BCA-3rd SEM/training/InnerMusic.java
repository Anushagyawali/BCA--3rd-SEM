 interface Music {
    void play();
}

class Ukilili implements Music{
    public void play(){
        System.out.println("Playing Ukilili");
    }
}

class Guitar implements Music{
    public void play(){
        System.out.println("Playing Guitar");
    }
}

public class InnerMusic {
    public static void main(String[] args) {
        Music instrument1 = new Ukilili();
        Music instrument2 = new Guitar();

        instrument1.play();
        instrument2.play();
    }

    
}
public class Index{
public Index (){
}
public static void main(String args [])
{
String text = "Hello Nepathya 3rd sem BCA";
int num = 5;
System.out.println(text);

String firstname ="Anusha";
String surname = "Gyawali";
System.out.println("My name is " + firstname + " " + surname);
}
}
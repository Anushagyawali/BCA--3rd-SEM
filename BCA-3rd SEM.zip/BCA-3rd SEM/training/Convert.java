public class Convert {
    public static void main(String[] args) {
        int num = 4;
        String a = String.valueOf(num);
        System.out.println("num");

        String b = "6";
        int c = Integer.parseInt(b);
        System.out.println(c);
    }
}

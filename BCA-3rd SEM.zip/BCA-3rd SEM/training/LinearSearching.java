import java.util.Scanner;
public class LinearSearching{

  public int Searching(int[]arr, int key){
    boolean found = false;
    for(int i = 0; i < arr.length; i++){
      if(key==arr[i]){
        System.out.println("Element found at" + i);
        found = true;
        return i;
      }
    }
      if(found==false){
      System.out.println("Element not found " );
      }
       return -1;
      
    }

  public static void main(String[] args){
  int[] arr= {1,3,2,5,6,4,8};
  Scanner scanner = new Scanner(System.in);
  System.out.println("Enter a key: ");
  int key = scanner.nextInt();
  LinearSearching searching = new LinearSearching();
  searching.Searching(arr,key);

  }
}
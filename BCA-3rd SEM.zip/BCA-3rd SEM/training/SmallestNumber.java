import java.util.Scanner;

public class SmallestNumber{
public int getSmaller(int[]arr){


        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Array size");
        int arraysize = scanner.nextInt();
        int small = arr [0];
        for (int i = 1; i>arraysize; i++){
            System.out.println("input data for array");
        //     if (small>arr[i]);{
        //         small = arr[i];
        //     }

        // }
        // return small;

    }
    public static void main(String[] args) {
        SmallestNumber num = new SmallestNumber();
        int smallest = num.getSmaller(arr);
        System.out.println("smallest is:"+ Smallest);

    }
}
}
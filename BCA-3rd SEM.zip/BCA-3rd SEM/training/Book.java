public class Book {
    String title;
    String author;
    double price;
    public Book(String title, String author, double price){
        this.title = title;
        this.author = author;
        this.price = price;
    }
    void displayDetails(){
        System.out.println("Title:" + title);
        System.out.println("Author:"+ author);
        System.out.println("Price:"+ price);
    }

    public static void main(String[] args) {
        Book book1 = new Book("ugly love", "numa", 1000);
        Book book2 = new Book("It starts with us", "Coolen hover", 10000);
        Book book3 = new Book("OOP in java", "Coolen hover", 1000);

        book1.displayDetails();
        book2.displayDetails();
        book3.displayDetails();
    }
}

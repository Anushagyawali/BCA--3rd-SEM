import java.util.Scanner;
public class Students{
    String name;
    int age;
    float grade;

    public Students(String name, int age, float grade){
        this.name = name;
        this.age = age;
        this.grade = grade;
    }
     
         public float getGrade(){
        return grade;
    }
public void displayDetails(){
    System.out.println("Name:"+ name +", Age:"+ age +", Grade:" + grade);
}

public static void main (String[]args){
    Scanner scanner = new Scanner(System.in);
    Students [] students = new Students[5];

    for(int i=0; i<5; i++){
        System.out.println("Enter name, age, grade");
        students[i] = new Students(scanner.next(), scanner.nextInt(), scanner.nextFloat());
    }
    for(Students a : students){
        a.displayDetails();
    }
}
}
// an order collection that allows to store duplicate elements.
// Elements can be accessed by Index
//  commom Implementation
// ArrayList : Dynamic array, fast access
// LinkedList: Doubly Linked list , better for insert/ delete.

import java.util.ArrayList;
import java.util.List;

public class ListInterfaceExample {
    public static void main(String[] args) {
        
        List<String> names = new ArrayList<>();
        names.add("Csit");
        names.add("BCA");
        names.add("Csit");

        System.out.println(names.get(1));
    }

    
}

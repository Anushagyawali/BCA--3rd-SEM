import java.util.Set;
import java.util.HashSet;

public class SetInterfaceExample {
    public static void main(String[] args) {
        Set<String> setexample =  new HashSet<>();
        setexample.add("CSIT");
        setexample.add("BCA");
        setexample.add("CSIT");

        System.out.println(setexample);

    
}
    
}

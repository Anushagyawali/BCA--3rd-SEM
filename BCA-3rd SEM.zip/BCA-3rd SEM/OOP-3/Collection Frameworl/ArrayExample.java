import java.util.Arrays;
public class ArrayExample{

    public static void main(String[] args) {
        int[] numbers = new int[5];
        numbers[0] = 10;
        numbers[1] = 20;
        numbers[2] = 30;
        numbers[3] = 40;
        System.out.println(Arrays.toString(numbers));

        String[] string = new String[4];
        string[0] = "Anusha";
        string[1] = "Chuchumeeta";
        string[2] = "Reetika";
        string[3] = "Kripa";

        System.out.println(Arrays.toString(string));


    }
}

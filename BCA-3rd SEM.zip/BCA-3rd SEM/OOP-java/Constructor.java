public class Constructor {
    // Default Constructor
    Constructor(){
        System.out.println("Constructor called !");
    }
    public static void main(String[] args) {
        Constructor constructor = new Constructor();
    }
}

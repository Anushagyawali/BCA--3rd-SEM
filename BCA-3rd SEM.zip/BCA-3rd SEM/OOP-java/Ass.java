public class Ass {
    public static void main (String[] args){
        int num = 100;
        while (num >= 1){
            System.out.println(num);
            num -= 2;
        }
    }
    
}

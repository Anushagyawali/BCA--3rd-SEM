// import java.util.Scanner;
// public class AskInput {
//     public static void main(String[] args) {
//     Scanner scanner= new Scanner(System.in);
//     System.out.println("Enter any number:");

//     int intNumber = scanner.nextInt();
//     float floatNumber = scanner.nextFloat();
//     double doubleNumber = scanner.nextDouble();
//     System.out.println("The entered integer number is:"+ intNumber);

//     System.out.println("The entered float number is:"+ floatNumber);

//     System.err.println("The entered double number is:"+ doubleNumber);

// scanner.close();
//     }
// }

import java.util.Scanner;
public class AskInput{
    public static void main(String[] args){
    Scanner Scanner=new Scanner (System.in);

    System.out.println("Enter any Character");
    char charIn= Scanner.next().charAt(0);
    
    
    //Ask a word
    System.out.println("Enter a Word");
    String stringIn= Scanner.next();

    Scanner.nextLine();

    //Ask a sentence
    System.out.println("Enter a sentence");
    String sentenceIn= Scanner.nextLine();

    System.out.println("The entered Character is:" + charIn);
    System.out.println("The entered Word is:" + stringIn);
    System.out.println("The entered Sentence is:" + sentenceIn);
    }}
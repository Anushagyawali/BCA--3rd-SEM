public class ControlStatement {
    public static void main(String[]args){
        // if-else syntax;
        // if(condition){
        // if block
        // }else (condition){
        // else block
        // }
    int age=20;
    if(age>=18){
        System.out.println("Eligible to vote!");
 }else{
    System.out.println("Not eligible to vote");
 }


 int num = 10;
 if(num>=0){
    System.out.println("The num is positive");
 }
 else if(num<=0){
    System.out.println("The num is negative");

 }
 else if (num==0){
    System.out.println("The num is zero");
 }
else{
    System.out.println("The num is invalid");
}
 



// switch
int day = 7;
switch(day){
    case 1: 
    System.out.println("Sunday");
    break;

    case 2: 
    System.out.println("Monday");
    break;

    case 3: 
    System.out.println("Tuesday");
    break;

    case 4: 
    System.out.println("Wednesday");
    break;

    case 5: 
    System.out.println("Thursday");
    break;

    case 6: 
    System.out.println("Friday");
    break;

    case 7: 
    System.out.println("Saturday");
    break;



    default:
    System.out.println("Invalid day");
    }
}
}
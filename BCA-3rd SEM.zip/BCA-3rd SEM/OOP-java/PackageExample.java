
    import Package.Myclass;

    public class PackageExample{
        public static void main(String[] args){
            Myclass obj = new Myclass();
            obj.displayMessage();


        }
    }



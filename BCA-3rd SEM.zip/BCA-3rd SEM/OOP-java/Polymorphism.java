public class Polymorphism {

    // ploymorphism: Having multiple forms
 // Method Overloading
// Example :
// 1. int add(int a , int b);
// 2. int add(int a, int b, int c);
// 3. double add(double a, double b, double c);

// Program Example
 static int add(int a, int b){
    return a + b;
}
//  Method Overload with 3 int parameters
static int add(int a, int b, int c){
    return a + b + c;
}

// Method Overload with 2 double type para,eters
 double add( double a, double b){
    return a + b;
}

public static void main(String[] args) {
    System.out.println("Addition of two numbers is:"+ add(3,3));
    System.out.println("Addition of two numbers is:"+ add(5,3));
    Polymorphism obj = new
    Polymorphism();
    double result = obj.add(4.5,5.5);
    System.out.println(("Addition of two numbers is:"+ result));
}
}

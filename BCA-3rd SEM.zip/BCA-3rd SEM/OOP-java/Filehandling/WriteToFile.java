import java.io.FileWriter;

public class WriteToFile {
    public static void main(String[] args) {
        try{
            FileWriter Writer = new FileWriter("example.txt");
            Writer.write("Hello java is a programming language");
            Writer.close();
            System.out.println("Successfullt write to file! ");
        } catch (Exception e){
            System.out.println("An error occured");
            e.printStackTrace();
        }
    }
}

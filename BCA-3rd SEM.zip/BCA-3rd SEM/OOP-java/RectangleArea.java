public class RectangleArea {
    static int area(int length, int breadth){
        return length*breadth;
    }
    static int area(int l, int b){
        return 2*(l + b);

    }
    public static void main(String[] args) {
        System.out.println("The area of rectangle is:"+ area (2,4));
        System.out.println("The perimete of rectangle is:"+ area(3,4));
    }
}

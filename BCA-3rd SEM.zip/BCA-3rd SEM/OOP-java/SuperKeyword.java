 class Parent {
    int number = 100;

    // constructor
    Parent(){
        System.out.println("Parent class constructor called");

    }

    // Parent method
    void otherMethod(){
        System.out.println(" Parent other method called");
    }

    // Parent second method
    void secondMethod(){
        System.out.println("Parent second method is called");
    }
}

    class Child extends Parent {
        int number = 200;

        // child method
        void display(){
            super.otherMethod();
            System.out.println("Parent class number"+ super.number);
            System.out.println("child class class number"+this.number);
        }

    }

    public class SuperKeyword{
        public static void main(String[] args) {
            Child child = new Child();
            child.display();
        }
    }


public class Person {
    // Data members
    String name;
    int age;
    float salary;

    // Parameterized Constructor
    Person(String _name, int _age, float _salary){
        this.name = _name;
        this.age = _age;
        this.salary = _salary;

    }
    void displayDetails(){
        System.out.println("Name:" + name);
        System.out.println("Age:" + age);
        System.out.println("Salary:" + salary);
    }
    public static void main(String[]args){

        Person person = new Person("Anusha", 21, 350.25f);
person.displayDetails();
    }
} 
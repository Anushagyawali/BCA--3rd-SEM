class Shape{
    void result(int length, int breadth, int height){
        System.out.println("This is result");
    }
}

class Cube extends Shape{
    void volumeofCube(int length){
        System.out.println("Volume of cube is:"+(length*length*length));
    }
}
class Cuboid extends Shape{
    void VolumeofCuboid(int length, int breadth, int height){
        System.out.println("Volume of Cuboid is:"+(length*breadth*height));
    }
}

public class ShapeExample{
    public static void main(String[]args){
        Cube cube = new Cube();
        cube.volumeofCube(3);

        Cuboid cuboid = new Cuboid();
        cuboid.VolumeofCuboid(3, 2, 1);

    }
}
// An abstract class can have both abstract(without body) and concrete methods.

abstract class Animal {
    abstract void makeSound();
void sleep(){
    System.out.println("Sleeping");
}
}

class Dog extends Animal{
    void makeSound(){
        System.out.println("Dogbarks");
    }

    
}

class Cat extends Animal{
    void makeSound(){
        System.out.println("Cat meows");
    }
}
public class DynamicAbstraction {
    public static void main(String[] args) {
        
        Animal animal;
        animal =  new Dog();
        animal.makeSound();

        animal = new Cat();
        animal.makeSound();
        

    }
}

class Vehicle{
    void run(){
        System.out.println("Vehicle is running");
    }
}
// Car- child class or sub class
class Car extends Vehicle{
    void stop(){
        System.out.println("Vehicle stopped");
    }
}

public class VehicleExample{
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle();
        vehicle.run();

        Car car = new Car();
        car.stop();
        car.run();
    }
}
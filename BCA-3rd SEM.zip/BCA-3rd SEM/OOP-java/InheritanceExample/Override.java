 class Animal {
    void makeSound(){
        System.out.println("Animal make sound");
    }
    
}

class Dog extends Animal{

    void makeSound(){
        System.out.println("Dog barks");
    }
}

public class Override{
    public static void main(String[] args) {
        Animal animal = new Animal();
        animal.makeSound();
    }
}
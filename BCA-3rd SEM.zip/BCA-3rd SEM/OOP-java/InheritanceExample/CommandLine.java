public class CommandLine {
    public static void main(String[] args) {
        // System.out.println(args[1]);

        for(int i = 0; i<=args.length -1 ; i++){
            System.out.println(args[i]);
        }
    }

    
}

class Animal {
    void makeSound(){
        System.out.println("Animal make sound");
    }
    
}

class Dog extends Animal{

    void makeSound(){
        System.out.println("Dog barks");
    }
}


class Cat extends Animal{

    void makeSound(){
        System.out.println("Cat meows");
    }
}


public class DynamicMethod {
    public static void main(String[] args) {
        Animal animal;
        animal =  new Dog();
        animal.makeSound();

        animal = new Cat();
        animal.makeSound();
        

    }
}

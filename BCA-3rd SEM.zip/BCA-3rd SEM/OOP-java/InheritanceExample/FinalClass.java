final class First{
    void firstMethod(){
        System.out.println("First method called");
    }
}

class Second{
    void secondMethod(){
        System.out.println("Second method called");
    }
}

public class FinalClass {
    public static void main(String[] args) {
        // final String name = "Charlie";
        // name = "Alpha";
        // System.out.println(name);

        Second second = new Second();
        second.secondMethod();

        Child employee1 = new Child();
        employee1.name = "Anusha";
        
        employee1.printDetails();
    }
}

class Person{
    String name;
    final int salary = 10000;
}
class Child extends Person{
    void printDetails(){
        System.out.println(name);
        System.out.println(salary);
}
}
interface Parent1{
     default void show(){
        System.out.println("Display parent 1 details");
    }
}

interface Parent2{
    default void show(){
        System.out.println("Display parent 2 details");
    }
}

class Child implements Parent1, Parent2{
public void show(){
System.out.println("Child details");
}
}

public class MultipleInheritance {
    public static void main(String[] args) {
        Child child = new Child();
        child.show();
    }
    
}

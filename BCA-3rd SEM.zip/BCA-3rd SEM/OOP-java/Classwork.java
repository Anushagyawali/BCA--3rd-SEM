public class Classwork {
    public static void main(String[] args) {
        boolean a = true;
        boolean b = false;
System.out.println("a || b:"+(a||b));
System.out.println("a && b:"+(a && b));

int c = 5;
int d = 7;
int addResult= (c+d);
int modeResult= (d%c);
System.out.println("The bitwise operator is:"+(~c));
System.out.println("addition:" + addResult);
System.out.println("modulus"+modeResult);
int e = 20;
int f = 13;
String message =(e>f) ? "eligible to vote": "not eligible to vote";
System.out.println(message);

int  v = 8;
System.out.println("Post Increment:"+(v++));
System.out.println("Pre Increment:"+(++v));


System.out.println("Post Decrement:"+(v--));
System.out.println("Pre Decrement:"+(--v));


int m = 7;
int rightShiftResult = m>> 3;
System.out.println("The Right shift by 3 is:"+rightShiftResult);


        
    }
}

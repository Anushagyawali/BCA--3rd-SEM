package StaticExample;

public class Outer2 {
    // Non-static Nested Class/ Inner Class
    // Create non ststic class
    class Inner{
        void displayInnerClassDetails(){
            System.out.println("Inside Non-static Nested (Inner) class");
        }
    }

    public static void main(String[] args) {
        Outer2 outer2 = new Outer2();
        Outer2.Inner nonStaticObjectExample = outer2.new Inner();
        nonStaticObjectExample.displayInnerClassDetails();

        
    }
}

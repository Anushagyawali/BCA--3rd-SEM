public class Example {

   public static void main(String[] args) {
     // concatination
     String a = "Ramey";
     String b = "poudel";
     String fullName = a+" "+b;
     System.out.println("COncatination Example : fullname: "+fullName);

    //  conversion
    int num = 321;
    String stringTONumber = String.valueOf(num);
    System.out.println(stringTONumber.getClass().getName());

    // mixed Case
    String mixedcase = "Hello World";
    System.out.println("Lower case: "+ mixedcase.toLowerCase());
    System.out.println("Upper Case: "+mixedcase.toUpperCase());


    // Extracting character
    String name = "Programmig";
    char firstChar = name.charAt(0);
    char fifthChar = name.charAt(4);
    System.out.println("First Character :"+ firstChar);
    System.out.println("Fifth Character :"+ fifthChar);



    //String comparison
    String s1 = "Java";
    String s2 = "Java";
    String s3 = new String("Java");
    String s4 = "java";

    //?? Using == 
    System.out.println("s1==s2 :"+ (s1==s2));
    System.out.println("s1==s3 :"+ (s1==s3));

    //?? Using .equalsIgnoreCase
    System.out.println(s1.equalsIgnoreCase(s4));



    // Searching string
    String text = "Java is a programming language";
    //Check if constains
    System.out.println("Contains programming :"+text.contains("programming"));
    // Index of string occurrence
    int firstIndex = text.indexOf("Java");
    System.out.println("First 'Java' is at :" +firstIndex);



    // count how many vowels and conconents are there in Nepathya college
    String input = "Nepathya college";
    int vowels = 0, consonants = 0;

   
    input = input.toLowerCase();

    for (int i = 0; i < input.length(); i++) {
        char ch = input.charAt(i);

        if (Character.isLetter(ch)) {
            if ("aeiou".indexOf(ch) != -1) {
                vowels++;
            } else {
                consonants++;
            }
        }
    }

    System.out.println("Vowels: " + vowels);
    System.out.println("Consonants: " + consonants);


    //Modifying String

    String originalString = "       java Programming    ";

    //Trim whitespace
    String trimmedString = originalString.trim();
    System.out.println("Removes whitespace string :" + trimmedString); // java programming

    
    // Replace text
    String replaceString = trimmedString.replace("java", "Python");
    System.out.println("Replaced String:" +replaceString);


    String replacedString;
    //concat
    String newString = replaceString.concat("is used for Artificial Intelligence");
    System.out.println("New string: " + newString);


    //String buffer
    StringBuffer stringBuffer = new StringBuffer("Hello");
    stringBuffer.append("World");
    stringBuffer.insert(5, "java");
    stringBuffer.reverse();
    System.out.println("Modified String buffer:"+ stringBuffer);
    
    
   }
}

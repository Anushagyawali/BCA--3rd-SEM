import java.util.Arrays;

public class Datatypes {
    public static void main(String[] args) {
        // variables are like containers where values can store
        // Datatypes are the type of data that variable can hold
        // java is statically typed language, which means every variables must have
        // sxpecific datatypes before use
        // Types of data types
        // 1. Premitive data type: It specifies the type and kund of value it can
        //  hold,the different types of premitive datatyps are given below:

        // 1. byte : (size=1 byte),(range: -127 to 128)
        byte byteExample = 100;
        System.out.println(byteExample);

        // 2. short:(size:2 bytes),(Range: -3,768 to 32,767)
        short shortExample = 32767;
        System.out.println(shortExample);

        // 3. int:(size=4 bytes),(Range: -2^31 to 2^31-1)
        int intExample= 327679887;
        System.out.println(intExample);

        // 4.long:(size:8 bytes)
        long longExample=1234567890L;
        System.out.println(longExample);

        // 5.float:(Stores values for decimal points,Sufficient for storing 6 to 7 decimal)
        float floatExample = 12.455f;
        System.out.println(floatExample);

        // 6. double:(stores values for decimal points.Sufficient for storing 15 to 16 decimal)
        double doubleExample=12.112d;
        System.out.println(doubleExample);

        // 7. boolean:(Stores boolean values either true or false)
        boolean booleanExample=true;
        System.out.println(booleanExample);

        // 8. char:(Stores a single character or ASCIT values)
        char charExample='A';
        System.out.println(charExample);

        // Non primitive datatype: These datatypes refers to objects or arrays
        // 1. String: Sequence of characters
        String collegeName ="Nepathya College";
        System.out.println(collegeName);
        
        // 2.Array: Collection of elements with same datatypes
        int[] arrayOfNumbers = {1,2,43,675};
        System.out.println(Arrays.toString(arrayOfNumbers));

        // 3.Class: Blueprint of an object

        // 4.Enum:Constants values in object (eg. dropdown in Gender field (male,female))




    }

}

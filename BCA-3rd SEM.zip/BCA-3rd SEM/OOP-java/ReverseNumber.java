//  import java.util.Scanner;
//     public class Exercise4{
  
//     public static void main (String [] args){
// //for loop io calculate summ of n number
// // Scanner sc = new Scanner(System.in);
// // int input = sc.nextInt();
// // int sum =0;
// // for(int i=1; i<=input; i++){
// //  sum = sum + i;
// // }


// System.out.println("-------------------------------------------");
// // print all even number between 1 to 50 using while loop 
// // int num =1;
// // while( num<=50){
// //     if(num %2 == 0){
// //         System.out.print(num + " ");
// //     }
// //     num++;
// // }

// System.out.println("-------------------------------------------");
// //print number from 100 to 1 in reverse using while loop


// // int num2 =100;
// // while (num2>=1){
// //     System.out.print(num2 + " ");
// //     num2--;
// // }

// System.out.println("-------------------------------------------");

// //print a factorial of n using for loop
// Scanner sc1 = new Scanner(System.in);
// System.out.println("Enter a num :");
// int input1  =sc1.nextInt();
// // int num1=1 ;
// // for(int i =1;i<=input1;i++){
// //     num1 = num1*i;
// // }

// // System.out.print(num1);

// System.out.println("-------------------------------------------");
//  //fibonacci using for loop
// //  int a =0;
// //  int b=1;
// //  int c;
// // for(int i=0; i <input1; i++){
// //     System.out.print(a);
// //     c = a+b;
// //   a=b;
// //     b=c;
// // }
// System.out.println("-------------------------------------------");

// //reverse of digits using while loop
// int reversed =0;
// while(input1> 0 ){
//   int  digit =  input1 %10;
//   reversed = reversed*10+digit;
//   input1 = input1/10;
// }
// System.out.print(reversed);
// //     }
// // }
// // import java.util.Scanner;

// // public class Exercise4{
// //     public static void main (String [] args){
// // //for loop io calculate summ of n number
// // // Scanner sc = new Scanner(System.in);
// // // int input = sc.nextInt();
// // // int sum =0;
// // // for(int i=1; i<=input; i++){
// // //  sum = sum + i;
// // // }


// // System.out.println("-------------------------------------------");
// // // print all even number between 1 to 50 using while loop 
// // // int num =1;
// // // while( num<=50){
// // //     if(num %2 == 0){
// // //         System.out.print(num + " ");
// // //     }
// // //     num++;
// // // }

// // System.out.println("-------------------------------------------");
// // //print number from 100 to 1 in reverse using while loop


// // // int num2 =100;
// // // while (num2>=1){
// // //     System.out.print(num2 + " ");
// // //     num2--;
// // // }

// // System.out.println("-------------------------------------------");

// // //print a factorial of n using for loop
// // Scanner sc1 = new Scanner(System.in);
// // System.out.println("Enter a num :");
// // int input1  =sc1.nextInt();
// // // int num1=1 ;
// // // for(int i =1;i<=input1;i++){
// // //     num1 = num1*i;
// // // }

// // // System.out.print(num1);

// // System.out.println("-------------------------------------------");
// //  //fibonacci using for loop
// // //  int a =0;
// // //  int b=1;
// // //  int c;
// // // for(int i=0; i <input1; i++){
// // //     System.out.print(a);
// // //     c = a+b;
// // //   a=b;
// // //     b=c;
// // // }
// // System.out.println("-------------------------------------------");

// // //reverse of digits using while loop
// // int reversed =0;
// // while(input1> 0 ){
// //   int  digit =  input1 %10;
// //   reversed = reversed*10+digit;
// //   input1 = input1/10;
// // }
// // System.out.print(reversed);
// //     }





// import java.util.Scanner;

// public class ReverseNumber {
//     public static void main(String[] args) {
//         // Create a scanner object to get user input
//         Scanner scanner = new Scanner(System.in);

//         // Prompt the user to enter a number
//         System.out.print("Enter a number: ");
//         int number = scanner.nextInt();
        
//         // Variable to store the reversed number
//         int reversedNumber = 0;

//         // While loop to reverse the number
//         while (number != 0) {
//             // Get the last digit of the number
//             int digit = number % 10;
            
//             // Add the digit to the reversed number
//             reversedNumber = reversedNumber * 10 + digit;
            
//             // Remove the last digit from the number
//             number = number / 10;
//         }

//         // Output the reversed number
//         System.out.println("Reversed Number: " + reversedNumber);
        
//         // Close the scanner
//         scanner.close();
//     }
// }




// 

import java.util.Scanner;

// public class ReverseNumber {
//     public static void main(String[] args) {
//         Scanner scanner = new Scanner(System.in);
//         System.out.print("Enter a number: ");
//         int number = scanner.nextInt();
        
//         int reversedNumber = 0;
//         while (number != 0) {
//             reversedNumber = reversedNumber * 10 + number % 10;
//             number = number / 10;
//         }
        
//         System.out.println("Reversed Number: " + reversedNumber);
//         scanner.close();
//     }
// }




class Car {
    String brand;
    int speed;

void displayCarDetails(){
    System.out.println("Brand + brand");
    System.out.println("Speed+ speed");
}
}

public class OopExample {
    public static void main(String[] args) {
        Car car1= new Car(); 


        car1.brand="BMW";
        car1.speed = 42;
        car1.displayCarDetails();
    }

    
}



    

    

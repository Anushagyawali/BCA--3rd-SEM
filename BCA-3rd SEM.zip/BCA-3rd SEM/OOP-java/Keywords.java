public class Keywords {
    public static void main(String[]args){
        // Constants: constants are the keywords whose values cannot be reassigned;
        final double PI = 3.14;
        System.out.println(PI);

        // Identifiers:
        int age = 40; 
        String name ="Alpha";

        // Literals;
        int firstNumber = 40;
        boolean isActive = false;

    }
    
}

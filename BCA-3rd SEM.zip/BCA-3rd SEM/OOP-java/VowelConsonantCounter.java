public class VowelConsonantCounter {
    public static void main(String[] args) {
        String text = "nepathya college";
        int vowels = 0, consonants = 0;

        // Convert to lowercase to handle capital letters too
        text = text.toLowerCase();

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);

            // Check if character is a letter
            if (Character.isLetter(ch)) {
                // Check if vowel
                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                    vowels++;
                } else {
                    consonants++;
                }
            }
        }

        System.out.println("Vowels: " + vowels);
        System.out.println("Consonants: " + consonants);
    }
}

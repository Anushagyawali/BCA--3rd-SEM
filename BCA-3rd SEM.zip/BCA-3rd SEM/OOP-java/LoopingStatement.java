import java.util.Scanner;
public class LoopingStatement{
    public static void main(String[]args){
        Scanner scanner = new Scanner(System.in);
    //     System.out.println("enter a number");
    //     int num = scan.nextInt();
    //     // System.out.println("Multiplication table of:");
    //     // for(int i = 1; i<=10; i++){
    //     //     System.out.println(num + "x" + i + "=" + (num*i));
    //     System.out.println("The number is:");
    //     if(num % 2==0){
    //         System.out.println("The number is even");
    //     }else
    //     System.out.println("The number is odd");
    //     }
    //     }



    // // For loop
    // syntax:
    // for(initialization; condition; increment/decrement){}

    // while
    // syntax: while(condition){expression}
    // Scanner scanner = new Scanner(System.in);
     int enterNumber;
//      while(true){
//         System.out.println("Enter the number");
//         enterNumber= scanner.nextInt();

//         if(enterNumber==5){

        
//         System.out.println("Exiting...");
//      }
// scanner.close();
//     }
// }
// }
    // do while
    // syntax: do{expression}while(condition);

    do{
        System.out.println("Enter the number");
        enterNumber= scanner.nextInt();
        
    }

        while(enterNumber != 5);
        System.out.println("You entered 5: Exiting");
    
        scanner.close();
     
    }
}

import java.util.Scanner;
public class FunctionExample {
    int mulResult = ( int num1 * int num2){
        result = (num1 * num2);
    }
    //     return a +b;
    
    public static void main(String [] args){
        // int firstResult = addition(10 , 20);
        // int secondResult = addition(60,40);
        // System.out.println(firstResult);
        // System.out.println(secondResult);

        

        int num1 = 10;
        int num2 = 15;
        int result = (num1 * num2);
        System.out.print(" The multiplication of + num1 + and +num2 is", + result);





    }

    public int getMulResult() {
        return mulResult;
    }

    public void setMulResult(int mulResult) {
        this.mulResult = mulResult;
    }

    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }
    
}
  
public class Deadlock {
    // create resources
    private static final Object resource1 = new Object();
    private static final Object resource2 = new Object();
    public static void main(String[] args) {
        // Thread 1 (task 1)
        Thread t1 = new Thread(()-> {
            synchronized(resource1){
                System.out.println("Thread 1 is using Resources 1");
                try{
                    Thread.sleep(100);
                }   catch(InterruptedException e){
                    e.printStackTrace();
                }   

                synchronized(resource2){
                    System.out.println("Thread 1 is using Resources 2");
                }
                  }

        });

        // create second thread or task 2
        Thread t2 = new Thread(()->{
            synchronized(resource1){
                System.out.println("Thread 2 is using Resource 2");

                try{
                    Thread.sleep(100);
                } catch (InterruptedException e){
                    e.printStackTrace();
                }


                synchronized(resource2){
                    System.out.println("Thread 2 is using Resource 1");
                }
            }

        });

        t1.start();
        t2.start();
    }

}

public class Operators {
    public static void main(String[]args){
        // Operators: Operators are the symbol used to perform operations(+,-,<,>,!=,==)
        // Operands: Operands are the variables;
        // (a+b): a and b are operands, + is an operator

        // 1. Arithmatic Operator: Performs Mathematical calculation. +, -, *, /
        // int a=20;
        // int b=30;
        // float c = 20f;
        // float d = 30f;
        // float e = 20f;
        // float f = 30f;
        // int addResult = a + b;
        // float subbResult = c - d;
        // int multiResult = a* b;
        // float divResult = a/b;
        // char ASCII = 66;
        // System.out.println("Addition:" + addResult);
        // System.out.println("Subtraction:" + subbResult);
        // System.out.println("Multiplication:" + multiResult);
        // System.out.println("Division:" + divResult);
        // System.out.println("Java is a programming Language");
        // System.out.println(ASCII);

//         System.out.println("..............");
  

// // 2. Relational Operator: Compare between two or more tha two values(<,>,==,<=,>=,!=)
// int c = 30;
// int d = 40;
// System.out.println("c > d:"+ (c > d));
// System.out.println("c < d:"+ (c < d));
// System.out.println("c == d:"+ (c == d));
// System.out.println("c <= d:"+ (c <= d));
// System.out.println("c >= d:"+ (c >= d));
// System.out.println("c != d:"+ (c != d));

// System.out.println("........");

// // 3. Logical Operator:Operation on boolean values
// // eg. AND(&&),OR(||),NOT(!)
// boolean x = true;
// boolean y = false;
// System.out.println("x && y:" + (x && y));
// System.out.println("x || y:" +(x || y));
// System.out.println("!x:" +(!x));

// // 4. Assignment Operator: It is used to assign the values
// // Operators: (+=, _=, /=, %=, =)
// int i = 2;
// i +=2;
// System.out.println("i");
// System.out.println("f -= g:"+(f -= g));
// System.out.println("f /= g:"+(f /= g));
// System.out.println("f *= g:"+(f *= g));
// System.out.println("f %= g:"+(f %= g));


// // Ternary Operator:
// // Syntax:(condition)? "if true":"if false"
int k = 10;
int l = 20;
String message =(k < l)? "K is greater than L": "K is less than L";
System.out.println(message);

System.out.println("..........");


// Bitwise Operators: operation on bits
// Operators:&,|,^,~
int m = 9; 
int n = 10;
 System.out.println("The Bitwise AND is:"+(m & n));
System.out.println("The Bitwise OR is:"+(m|n));
System.out.println("The Bitwise XOR is:"+(m^n));
System.out.println("The Bitwise COMPLEMENT is:"+(~m));
    

// post increment and pre increment

int  v = 5;
System.out.println("Post Increment:"+(v++));
System.out.println("Pre Increment:"+(++v));


System.out.println("Post Decrement:"+(v--));
System.out.println("Pre Decrement:"+(--v));

System.out.println("...........");


// shift operators:used to manipulate the bits.
// left shift(<<): shift the left to the bit to the left and fills 0 to the right

int z= 2;
int leftShiftResult = z<<1;
System.out.println("The left shift by 1:"+ leftShiftResult);

    }
}


public class FlowLayout {

    public static final String FlowLayoutLeft = null;

}

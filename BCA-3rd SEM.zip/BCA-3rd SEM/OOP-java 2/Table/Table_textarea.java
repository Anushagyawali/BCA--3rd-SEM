package Table;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;


public class Table_textarea {
    public static void main(String[] args) {
        JFrame jFrame = new JFrame("JTable and JText");
        jFrame.setSize(800,700);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLayout(null);


        String[][] data = {
            {"1", "Anita" , "Fourth" , "BCA"},
            {"2","Sneha" , "First" , "CSIT"},
            {"3" , "Soniya" , "Fifth", "BBA"},
            {"4" , "Anusha" , "Sixth" , "MBA"},
            {"5" , "Susmita", "Second" , "BBS"},
            {"6" , "Reetika", "Eighth", "BED"},
        };

        String[] columnNames = {"ID" , "Name" , "Semester" , "Faculty"};
        JTable jtable = new JTable(data, columnNames);
        JScrollPane tableScrollPane = new JScrollPane(jtable);
        tableScrollPane.setBounds(50, 50, 300, 100);

        jFrame.add(tableScrollPane);

        JTextArea jTextArea = new JTextArea("Enter something here...........");
        JScrollPane textJScrollPane = new JScrollPane(jTextArea);
        textJScrollPane.setBounds(50, 200, 300, 120);
        jFrame.add(textJScrollPane);


        jFrame.setVisible(true);

        

    }
    
}
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class FlowLayouttExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Event handing ");
        frame.setSize(350,300);
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton button1 = new JButton("Submit");
        // set button position and size 
        // button1.setBounds(50,100,120,30);
        frame.add(button1);

        JButton button2 = new JButton("Submit");
        // set button position and size 
        // button2.setBounds(50,150,120,30);
        frame.add(button2);

        JButton button3 = new JButton("Submit");
        // set button position and size 
        // button3.setBounds(50,200,120,30);
        frame.add(button3);

        frame.setVisible(true);
    }
}
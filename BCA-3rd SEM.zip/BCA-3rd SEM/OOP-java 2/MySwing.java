import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

public class MySwing {
    public static void main(String[] args) {
        // Create a frame
        JFrame jFrame = new JFrame("My Swing Application");

        // Set frame size
        jFrame.setSize(500, 400);

        // Close operation
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set default layout
        jFrame.setLayout(null);

        // Username
        JLabel jLabelUsername = new JLabel("Username");
        jLabelUsername.setBounds(50, 20, 200, 30);
        JTextField jTextFieldUsername = new JTextField(20);
        jTextFieldUsername.setBounds(50, 50, 200, 30);

        // Full Name
        JLabel jLabelFullName = new JLabel("Full Name");
        jLabelFullName.setBounds(50, 90, 200, 30);
        JTextField jTextFieldFullName = new JTextField(20);
        jTextFieldFullName.setBounds(50, 120, 200, 30);

        // Password
        JLabel jLabelPassword = new JLabel("Password");
        jLabelPassword.setBounds(50, 160, 200, 30);
        JPasswordField jPasswordField = new JPasswordField(20);
        jPasswordField.setBounds(50, 190, 200, 30);

        // Phone Number
        JLabel jLabelPhone = new JLabel("Phone Number");
        jLabelPhone.setBounds(50, 230, 200, 30);
        JTextField jTextFieldPhone = new JTextField(20);
        jTextFieldPhone.setBounds(50, 260, 200, 30);

        // Submit button
        JButton jButton = new JButton("Submit");
        jButton.setBounds(50, 310, 200, 30);

        // Add components to frame
        jFrame.add(jLabelUsername);
        jFrame.add(jTextFieldUsername);
        jFrame.add(jLabelFullName);
        jFrame.add(jTextFieldFullName);
        jFrame.add(jLabelPassword);
        jFrame.add(jPasswordField);
        jFrame.add(jLabelPhone);
        jFrame.add(jTextFieldPhone);
        jFrame.add(jButton);

        // Set visibility
        jFrame.setVisible(true);
    }
}

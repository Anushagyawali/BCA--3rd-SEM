import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class MySwingApp {

    public static void main(String[] args) {
        // create a frame
        JFrame jFrame = new JFrame("My swing application");

        // Set Frame Size
        jFrame.setSize(500, 300);

        // Close operation
        jFrame.setDefaultCloseOperation(jFrame.EXIT_ON_CLOSE);

        // Set default layout
        jFrame.setLayout(null);

        // Create components
        JLabel jLabel = new JLabel("Enter your name");
        jLabel.setBounds(50, 100, 200, 100);

        JTextField jTextField = new JTextField(20);
        jTextField.setBounds(50 , 100, 200, 100);

        JButton jButton = new JButton("submit");
        jButton.setBounds(50 , 100, 200, 100);

        jFrame.add(jLabel);
        jFrame.add(jTextField);
        jFrame.add(jButton);


        // Set visibility
        jFrame.setVisible(true);
    }
}
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class MenuExample {
    public static void main(String[] args) {
         JFrame jFrame = new JFrame("Menu Example ");
        jFrame.setSize(600,500);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        // Menu bar
        JMenuBar menuBar = new JMenuBar();


        JMenu filemenu = new JMenu("File");
        JMenuItem openItem = new JMenuItem( "Open");
        JMenuItem saveItem = new JMenuItem("Save");

        filemenu.add(openItem);
        filemenu.add(saveItem);
        menuBar.add(filemenu);




        jFrame.setJMenuBar(menuBar);
        jFrame.setVisible(true);


    }
}

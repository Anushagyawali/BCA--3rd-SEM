import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

public class ChoiceComponentExample {
    public static void main(String[] args) {
        JFrame jFrame = new JFrame("choice component ");
        jFrame.setSize(600,500);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLayout(null);;


        // yo checkBox example ho
        JCheckBox jCheckBox1 = new JCheckBox("C-programming");
        JCheckBox jCheckBox2 = new JCheckBox("JAVA");
        JCheckBox jCheckBox3 = new JCheckBox("C++");
        JCheckBox jCheckBox4 = new JCheckBox("python");

        jCheckBox1.setBounds(50,50,100,30);
        jCheckBox2.setBounds(50,80,100,30);
        jCheckBox3.setBounds(50,110,100,30);
        jCheckBox4.setBounds(50,140,100,30);

        jFrame.add(jCheckBox1);
        jFrame.add(jCheckBox2);
        jFrame.add(jCheckBox3);
        jFrame.add(jCheckBox4);


        jCheckBox1.addActionListener(e ->{
            if(jCheckBox1.isSelected()){
                JOptionPane.showMessageDialog(jFrame, "C-Programming is selected!");
            }
        });


        jCheckBox2.addActionListener(e ->{
            if(jCheckBox2.isSelected()){
                JOptionPane.showMessageDialog(jFrame, "JAVA is selected!");
            }
        });
      

        jCheckBox3.addActionListener(e ->{
            if(jCheckBox3.isSelected()){
                JOptionPane.showMessageDialog(jFrame, "C++ is selected!");
            }
        });


        jCheckBox4.addActionListener(e ->{
            if(jCheckBox4.isSelected()){
                JOptionPane.showMessageDialog(jFrame, "Python is selected!");
            }
        });



        
        JRadioButton rb1 = new JRadioButton("BCA");
        JRadioButton rb2 = new JRadioButton("CSIT");

        rb1.setBounds(200,50,100,30);
        rb2.setBounds(200,80,100,30);

        ButtonGroup genderGroup  = new ButtonGroup();
        genderGroup.add(rb1);
        genderGroup.add(rb2);

        jFrame.add(rb1);
        jFrame.add(rb2);


        rb1.addActionListener(e ->{
            if(rb1.isSelected()){
                JOptionPane.showMessageDialog(jFrame, "BCA is selected!");
            }
        });

        rb2.addActionListener(e ->{
            if(rb2.isSelected()){
                JOptionPane.showMessageDialog(jFrame, "CSIT is selected!");
            }
        });


    
        String[] language = {"Java", "C-programming", "python","C++"};
        JComboBox<String> cb = new JComboBox<>(language);

        cb.setBounds(200,150,100,30);

        jFrame.add(cb);

        cb.addActionListener(e ->{
            String selected = (String)cb.getSelectedItem();
            JOptionPane.showMessageDialog(jFrame,"You Selected: " + selected + "from combobox");
        });


        jFrame.setVisible(true);
    }
}
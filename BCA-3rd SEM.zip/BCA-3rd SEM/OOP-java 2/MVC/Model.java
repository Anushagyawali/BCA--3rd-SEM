package MVC;
public class Model {
    private String name = "";

    // Setter
    public void setName(String name){
        this.name = name;
    }

    // Getter
    public String getGreeting(){
        return "Hello" + name + "!";
    }
}

public class Quicksort {
static int Patation(int arr[], int low, int high){
            int pivot = arr[low];
            int i =low;
            for(int j = low+1;j<=high;j++){
                if(arr[j]<pivot){
                    i++;
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
        
        
            }
        
            int temp = arr[i];
            arr[i] = arr[low]; 
            arr[low] = temp;
            return i;
            
        }
            static void QuickSort(int arr[] , int l ,int r){
                if(l<r){
                    int pidx = Patation(arr, l ,r);
                    QuickSort(arr,l,pidx-1);
                    QuickSort(arr,pidx+1 ,r);
                }
            }
            public static void main(String[] args ){
                int []arr = {12,6,22,34,665,75,34,2};
                int size = arr.length;
                int r  = size-1;
                QuickSort(arr,0,r);
        for(int i=0;i<size;i++){
            System.out.print("\t" +arr[i]);
        }
            }
        }



        
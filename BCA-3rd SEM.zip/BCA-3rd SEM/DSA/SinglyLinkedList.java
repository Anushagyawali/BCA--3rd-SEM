
class Node{
    int data;
    Node next;

    public Node(int data){
        this.data = data;
        this.next = null;
    }
}
class Linked_list{
    Node head;

    void insertAtLast(int data){
        Node newNode = new Node(data);
        if(head ==null){
head = newNode;
            
        return;
        }
        Node currentNode = head;
        while(currentNode.next !=null){
               currentNode =  currentNode.next;
        }
       currentNode.next = newNode;

    }

    void deleteFromFirst(){
        if(head == null ){
            System.out.println("List is empty!!");
            return;
        }
        System.out.println("Deleted element :" +head.data);
        head = head.next;
    }

 void insertAtFirst(int data){

        Node newNode = new Node(data);
        if(head == null ) {
            head = newNode;
            return;
        }
        newNode.next = head;
        head = newNode;
    }

    void deleteFromLast(){
        if(head == null ){
            System.out.println("List is empty");
            return;
        }
if(head.next == null){
    System.out.println("Deleted element : " + head.data);
    head = null;
    return;
}
Node temp = head;
while(temp.next.next != null){
        temp = temp.next;
}
System.out.println("Deleted element : " + temp.next.data);
temp.next = null;


    }

void insertAtNPosition(int data , int position){
    Node newNode = new Node(data);
   if(position == 0){
    newNode.next = head;
    head = newNode;
    return;
   }
   Node temp = head;
   int counter = 0;
   while(temp != null && counter<position-1){
    temp = temp.next;
    counter++;
   }
   if(temp !=null){
    newNode.next = temp.next;
    temp.next = newNode;
    
   }else{
System.out.println("Position out of bounds!!");
   }

}

void deleteFromNPosition(int position){
    if(head == null){
        System.out.println("List is empty!!");
return;
    }
if(position ==0){
    System.out.println("Deleted element :"+head.data);
    head = head.next;
    return;
}
Node temp = head;
int counter =0;
while(temp !=null  && counter<position-1){
    temp = temp.next;
    counter++;
}
  
if(temp != null && temp.next !=null){
    System.out.println("Deleted element :" +temp.next.data);
    temp.next = temp.next.next;
}else{
    System.out.println("Position out of bounds!!");
}
}

void print(){

   
    if(head == null) {
        System.out.println("List is empty");
        return;
    }
    Node currentNode = head;
    while (currentNode !=null){
        System.out.print(currentNode.data + " -> ");
        currentNode = currentNode.next;
    }
    System.out.println("NULL");
}
  void printHeading(String heading) {
        System.out.println("\n");
        System.out.println(heading);
    }

}


public class SinglyLinkedList{
    public static void main(String [] args){
    Linked_list  l1 = new Linked_list();
  l1.printHeading("Inserting at Last");
    l1.insertAtLast(28);
    l1.insertAtLast(8);
    l1.insertAtLast(17);
       l1.print();
       l1.printHeading("Inserting at First");
       l1.insertAtFirst(18);

l1.insertAtFirst(2);
l1.insertAtFirst(11);
l1.print();
   l1.printHeading("Inserting at Nth Position");
l1.insertAtNPosition(7,2);
l1.insertAtNPosition(8,4);
l1.print();
  l1.printHeading("Deleting from Last");
l1.deleteFromLast();
l1.print();
l1.printHeading("Deleting from First");
l1.deleteFromFirst();
l1.print();
l1.printHeading("Deleting from Nth Position");
    l1.deleteFromNPosition(2);
    l1.print();
 
 
    }
}


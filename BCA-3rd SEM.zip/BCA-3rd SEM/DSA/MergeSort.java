public class MergeSort{
    public static void main(String  [] args){
        int []arr = {12,43,2,4,5,23,100,7};
        int size = arr.length;
        int l = 0;
        int r =size-1;
        
         System.out.println("Unsorted array : ");   
print(arr,size);
   

      mergeSort(arr,l,r);


      System.out.println("Sorted array : ");
print(arr,size);
    }



       static void print(int []arr,int size){
for(int i=0;i<size;i++){
    System.out.print(arr[i] +" \t" );
}
 System.out.print("\n");
}

static void merge(int []arr, int l , int mid, int r){
    int k=0;
    int i=l;
int j =mid+1;
    int size = r-l+1;
    int []temp = new int[size];
    while(i<=mid && j<=r ){
if(arr[i]<arr[j]){
    temp[k++] = arr[i++];
}else{
    temp[k++] =arr[j++];

}
    }

    while(i<=mid){
        temp[k++]  = arr[i++];
    }
    while(j<=r){
        temp[k++] = arr[j++];
    }

    for( i =0; i<size;i++){
        arr[i+l] = temp[i];
    }
}

static void mergeSort(int []arr, int l ,int r){
    if(l<r){
        int mid = (l+r)/2;
        mergeSort(arr,l,mid);
        mergeSort(arr,mid+1,r);
 merge(arr,l,mid,r);
    }
}

}
#include<stdio.h>
int main(){
    int a[] ={1,2,3,4,5,6,7,8};
    int searchelement = 2;
    int start = 0;
    int end = size of(a) /size of(a[0])-1;
    int mid = (start + end)/2;
    int n = 8;
    for(int i=0; i<n;i++)
    {
        printf("number %d index %d\n",a[i])
        if(a[mid] == searchelement){
            break;
        }
        if(a[mid]<searchelement){
            start = mid + 1;

        }
        else 
        end = mid-1;
    mid =(start + end) /2;
    printf("\t%d\t mid\t",mid);
        }
    }
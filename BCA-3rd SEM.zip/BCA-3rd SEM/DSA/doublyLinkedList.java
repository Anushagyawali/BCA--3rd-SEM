
class Node {
    int data; 
    Node next;
    Node prev;

   public  Node(int data){
    this.data = data;
   }
}
class LinkedList{
    Node head;

    void insertAtFirst(int data){
    Node newNode = new Node(data);
    if(head == null){
        head = newNode;
        return;
    }
    newNode.next = head;
   head.prev = newNode;
   head = newNode;

}
void deleteFromFirst(){
    if(head == null ){
        System.out.println("List is empty!!");
        return;
    }
    if(head.next == null){
        System.out.println("Deleted element: " + head.data);
        head = null;
        return;
    }
    System.out.println("Deleted element : " + head.data);
    head = head.next;
    head.prev = null;
}

void insertAtLast(int data){
    Node newNode = new Node(data);
    if (head == null){
      head = newNode;
       return; 
    }
    Node temp = head ;
    while (temp.next != null){
        temp =temp.next;
    }
    temp.next = newNode;
    newNode.prev = temp;

}
void  deleteFromLast(){
    if(head == null) {
        System.out.println("List is empty!!");
        return;
    }
    if(head.next == null){
        System.out.println("Deleted element : " + head.data);
        head = null;
        return;
    }
    Node temp = head;
    while(temp.next !=null){
        temp = temp.next;
    }
  System.out.println("Deleted element : " + temp.data);
  temp.prev.next = null;
}

void insertAtNPostion(int data , int position){
    Node newNode = new Node(data);
    if(position == 0){
     newNode.next = head;
   if(head != null){
    head.prev = newNode;
   }
   head = newNode;
     return;

    }
 Node temp = head;
 int counter = 0 ;
 while (temp !=null && counter<position-1){
    temp = temp.next;
    counter++;
 }
 if(temp == null){
    System.out.println("List has fewer element!!");
    return;
 }
 newNode.next = temp.next;
 newNode.prev = temp;

 if(temp.next !=null){
    temp.next.prev = newNode;
 }
 temp.next = newNode;
}

void deleteFromNPosition(int position) {
    if (head == null) {
        System.out.println("List is empty!!");
        return;
    }

    Node temp = head;

 
    if (position == 0) {
        System.out.println("Deleted element: " + head.data);
        head = head.next;
        if (head != null) {
            head.prev = null;
        }
        return;
    }


    int counter = 0;
    while (temp != null && counter < position) {
        temp = temp.next;
        counter++;
    }


    if (temp == null) {
        System.out.println("Invalid position!");
        return;
    }

   
    System.out.println("Deleted element: " + temp.data);

    if (temp.next != null) { 
        temp.next.prev = temp.prev;
    }

    if (temp.prev != null) {
        temp.prev.next = temp.next;
    }
}

void print (){
    Node temp = head ;
    if(head == null){
        System.out.println("List is empty");
    }
    while(temp!=null){
        System.out.print(temp.data + "-> ");
        temp=temp.next;

    }
    System.out.println("NULL");
}

void printHeading(String heading) {
        System.out.println("\n");
        System.out.println(heading);
    }


}

public class doublyLinkedList{
    public static void main(String [] args){
LinkedList l1 = new LinkedList();

       l1.printHeading("Inserting at First");
l1.insertAtFirst(24);
l1.insertAtFirst(34);
l1.insertAtFirst(44);
l1.print();

  l1.printHeading("Inserting at Last");
l1.insertAtLast(33);
l1.insertAtLast(15);
l1.insertAtLast(23);
l1.print();
   l1.printHeading("Inserting at Nth Position");
l1.insertAtNPostion(5,2);
l1.print();
 l1.printHeading("Deleting from Last");
l1.deleteFromLast();
l1.print();
l1.printHeading("Deleting from First");
l1.deleteFromFirst();
l1.print();
l1.printHeading("Deleting from Nth Position");
l1.deleteFromNPosition(2);
l1.print();

    }
}
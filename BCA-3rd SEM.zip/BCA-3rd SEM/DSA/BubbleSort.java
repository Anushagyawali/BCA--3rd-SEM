public class BubbleSort{
    public static void main (String [] args){

        int []arr = {23,4,12,43,65,45,2};
        int size = arr.length;

     System.out.println("Unsorted array : ");   
print(arr,size);
   

      sort(arr,size);


      System.out.println("Sorted array : ");
print(arr,size);
    }

    static void print(int []arr,int size){
for(int i=0;i<size;i++){
    System.out.print(arr[i] +" \t" );
}
 System.out.print("\n");
}
 static void sort(int []arr , int size ){
        for(int i=0;i<size-1;i++){
            for(int j=0;j<size-i-1;j++){
                if (arr[j] >arr[j+1]){
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }
        }
    }
}
public class InsertionSort{
    public static void main(String[] args){
        int [] arr = {12,34,5,21,34,43,6};
        int size = arr.length;
         System.out.println("Unsorted array : ");   
print(arr,size);
   

      sort(arr,size);


      System.out.println("Sorted array : ");
print(arr,size);
    }

    static void print(int []arr,int size){
for(int i=0;i<size;i++){
    System.out.print(arr[i] +" \t" );
}
 System.out.print("\n");
}

    static void sort(int []arr , int size){
        for(int i=1;i<size;i++){
 int num = arr[i];
             int j = i-1;
             while(j>=0 && num <arr[j]){
                arr[j+1] =arr[j];
                j--;
             }
             arr[j+1] = num;

        }
    }
}
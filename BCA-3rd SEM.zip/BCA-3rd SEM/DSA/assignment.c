#include<stdio.h>
int main(){
    int searchelement = 1;
    int start = 0;
    int end = sizeof a/size of a(0);
    int mid =(start+end/2);
    for(int i=0;i<n; i++)
}
if(searchelement==)
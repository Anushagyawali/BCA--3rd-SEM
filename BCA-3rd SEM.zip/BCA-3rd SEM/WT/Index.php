<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hello World</h1>
    <div class="form-group">
    <form action="table.php" method = "POST">
        <label>Name:</label>
        <input type="text" name ="name" placeholder ="Input your name"/>
    </form>
    </div>
    <div class="form-group">
    <form action="table.php" method = "POST">
        <label>Email:</label>
        <input type="email" name ="email" placeholder ="Enter Email:"/>
    </form>
    </div>
    <div class="form-group">
    <form action="table.php" method = "POST">
        <label>Password:</label>
        <input type="password" name ="password" placeholder ="Enter Password:"/>
    </form>
    </div>
    <div class="form-group">
    <form action="table.php" method = "POST">
        <label>Password:</label>
        <input type="submit" value="Submit">
    </form>
    </div>
</body>
</html>
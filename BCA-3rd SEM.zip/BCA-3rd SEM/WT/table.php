<?php
$name = "  Manish  ";
$name = " Srijit ";
$a = 5;


if($a > 4){
    echo "<h1> I am inside if </h1>";    
}
else{
    echo "<h1>  I am an else </h1>";
}

$name = $_POST["fname"];
// $name = $_POST"fname";

print "<h1>Hello, World!</h";
echo "Welcome ".$name;

?>
<?php
include "dbConnection.php";
$id=$_GET["id"];
function findById($id){
    global $conn;
    $query='SELECT*FROM student WHERE id=$id';
    $result =$conn->query($query)
    $row=$result->fetch_assoc();
    print_r($row);
    return $row;
    // $row;
    // $conn->query($query);
}
$currentRecord=  findById($id);
print_r($currentRecord);
if($_SERVER["REQUEST_METHOD"]==="POST"){
    updateRecord();
}
function updateRecord(){
    global $conn;
    global $id;
    $name=$_POST["name"];
    $email=$_POST["email"];
    $age=$_POST["age"];
    $gender=$_POST["gender"];
    $address=$_POST["address"];

    $query="UPDATE student SET name='$name',email='$email',age='$age',
     gender='$gender', address='$address' WHERE id='$id';";   
    //   $query="UPDATE TABLE student SET name='$name',email='$email',age='$age'
    //   gender='$gender',address='$address' WHERE id='$id'";
    // $result=$conn->query($query);
echo $query;
    if($conn->query($query)==TRUE){
        header("Location:index.php");
    }else{
        echo 'Something went wrong'.$conn->error;
    }
}
?>
<form method="POST">
<h1>Student Update Form</h1>
<div class="form-group">
<label form="name">Name</label>
<input type="text" name="name" placeholder="name"
value=<?php echo $currentRecord ['name'];?>
</div>

<div class="form-group">
<label form="age">Age</label>
<input type="number" name="Age" placeholder="Age"
value=<?php echo $currentRecord ['age'];?>
</div>

<div class="form-group">
<label>Gender</label>
<input type="radio" name="gender" value="male"
<?php echo $currentRecord ['gender']=="male"?"checked":""?>Male
<input type="radio" name="gender" value="female"
<?php echo $currentRecord ['gender']=="female"?"checked":""?>Female
</div>

<div class="form-group">
<label form="address"Address</label>
<textarea type="number" name="address" placeholder="Address"
<?php echo $currentRecord ['address'];?>
</textarea>
</div>

<div class="form-group">
    <input type="submit">
</div>
</form>
</body>
</html>
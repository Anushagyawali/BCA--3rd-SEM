<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CRUD App</title>
</head>
<body>
    <form action="#" method="POST">
        <label for="name">Full Name:</label>
        <input type="text" id="name" name="name" placeholder="Enter your name" required>
        <br><br>

  
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" placeholder="Enter your age" min="1" required>
        <br><br>

        <label>Gender:</label>
        <input type="radio" id="male" name="gender" value="male" required>
        <label for="male">Male</label>
        
        <input type="radio" id="female" name="gender" value="female" required>
        <label for="female">Female</label>

        <input type="radio" id="other" name="gender" value="other" required>
        <label for="other">Other</label>
        <br><br>

        <label for="reg-number">Registration Number:</label>
        <input type="text" id="reg-number" name="registration" placeholder="Enter registration number" required>
        <br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>
        <br><br>

        <input type="submit" value="Register">
    </form>


  
</body>
</html>
 